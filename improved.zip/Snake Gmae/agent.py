import torch
import random
import numpy as np
from collections import deque
from game import SnakeGameAI, Direction, Point
from model import Linear_QNet, QTrainer
from helper import plot
import time

MAX_MEMORY = 100_000
BATCH_SIZE = 1000

class Agent:

    def __init__(self):
        self.n_games = 0
        self.epsilon = 1.0  # Initial exploration
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.learning_rate = 0.001
        self.gamma = 0.9  # Discount factor
        self.memory = deque(maxlen=MAX_MEMORY) # popleft()
        self.model = Linear_QNet(30, 256, 3)
        self.trainer = QTrainer(self.model, lr=self.learning_rate, gamma=self.gamma)

    '''
    def adjust_learning_rate(self, score):
        self.learning_rate = max(0.0001, self.learning_rate * 0.99 if score < 50 else self.learning_rate * 1.01)
        for param_group in self.trainer.optimizer.param_groups:
            param_group['lr'] = self.learning_rate

        '''
    def directions(self, game):
        head = game.snake[0]
        dist = [0, 0, 0, 0, 0, 0, 0, 0]

        # North
        y = head.y
        while y > 0:
            y -= 1
            if (head.x, y) in game.snake[1:]:
                break
        dist[0] = abs(head.y - y)

        # North-East
        x, y = head.x, head.y
        while x < game.w and y > 0:
            x += 1
            y -= 1
            if (x, y) in game.snake[1:]:
                break
        dist[1] = ((head.x - x) ** 2 + (head.y - y) ** 2) ** 0.5

        # East
        x = head.x
        while x < game.w:
            x += 1
            if (x, head.y) in game.snake[1:]:
                break
        dist[2] = abs(head.x - x)

        # South-East
        x, y = head.x, head.y
        while x < game.w and y < game.h:
            x += 1
            y += 1
            if (x, y) in game.snake[1:]:
                break
        dist[3] = ((head.x - x) ** 2 + (head.y - y) ** 2) ** 0.5

        # South
        y = head.y
        while y < game.h:
            y += 1
            if (head.x, y) in game.snake[1:]:
                break
        dist[4] = abs(head.y - y)

        # South-West
        x, y = head.x, head.y
        while x > 0 and y < game.h:
            x -= 1
            y += 1
            if (x, y) in game.snake[1:]:
                break
        dist[5] = ((head.x - x) ** 2 + (head.y - y) ** 2) ** 0.5

        # West
        x = head.x
        while x > 0:
            x -= 1
            if (x, head.y) in game.snake[1:]:
                break
        dist[6] = abs(head.x - x)

        # North-West
        x, y = head.x, head.y
        while x > 0 and y > 0:
            x -= 1
            y -= 1
            if (x, y) in game.snake[1:]:
                break
        dist[7] = ((head.x - x) ** 2 + (head.y - y) ** 2) ** 0.5

        return dist  # gives 8 directional values
    
    def get_state(self, game):
        head = game.snake[0]
        point_l = Point(head.x - 20, head.y)
        point_r = Point(head.x + 20, head.y)
        point_u = Point(head.x, head.y - 20)
        point_d = Point(head.x, head.y + 20)
        
        dir_l = game.direction == Direction.LEFT
        dir_r = game.direction == Direction.RIGHT
        dir_u = game.direction == Direction.UP
        dir_d = game.direction == Direction.DOWN

        dist = self.directions(game)

        state = [
            # Danger straight
            (dir_r and game.is_collision(point_r)) or 
            (dir_l and game.is_collision(point_l)) or 
            (dir_u and game.is_collision(point_u)) or 
            (dir_d and game.is_collision(point_d)),

            # Danger right
            (dir_u and game.is_collision(point_r)) or 
            (dir_d and game.is_collision(point_l)) or 
            (dir_l and game.is_collision(point_u)) or 
            (dir_r and game.is_collision(point_d)),

            # Danger left
            (dir_d and game.is_collision(point_r)) or 
            (dir_u and game.is_collision(point_l)) or 
            (dir_r and game.is_collision(point_u)) or 
            (dir_l and game.is_collision(point_d)),
            
            # Move direction
            dir_l,
            dir_r,
            dir_u,
            dir_d,
            
            # Food location 
            game.food.x < game.head.x,  # food left
            game.food.x > game.head.x,  # food right
            game.food.y < game.head.y,  # food up
            game.food.y > game.head.y,  # food down

            int(game.snake[-1][0] < head[0]),  # Tail is to the left
            int(game.snake[-1][0] > head[0]),  # Tail is to the right
            int(game.snake[-1][1] < head[1]),  # Tail is above
            int(game.snake[-1][1] > head[1]),   # Tail is below

            # 8-directional distance
            dist[0],#N
            dist[1],#NE
            dist[2],#E
            dist[3],#SE
            dist[4],#S
            dist[5],#SW
            dist[6],#W
            dist[7],#NW

            # Threat of hitting own tail
            game.snake.count(point_l) > 1,
            game.snake.count(point_r) > 1,
            game.snake.count(point_u) > 1,
            game.snake.count(point_d) > 1,
           
            # Snake length growth
            len(game.snake) / (game.w * game.h),

            #Additional information
            game.score / 100,  # Normalized score
            (game.w * game.h - len(game.snake)) / (game.w * game.h)  # Available space

        ]

        """
            # Threat of hitting own tail
            game.trap_left,
            game.trap_right,
            game.trap_up,
            game.trap_down,
        """
        return np.array(state, dtype=int)

    def remember(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done)) # popleft if MAX_MEMORY is reached

    def train_long_memory(self):
        if len(self.memory) > BATCH_SIZE:
            mini_sample = random.sample(self.memory, BATCH_SIZE) # list of tuples
        else:
            mini_sample = self.memory

        states, actions, rewards, next_states, dones = zip(*mini_sample)
        self.trainer.train_step(states, actions, rewards, next_states, dones)
        #for state, action, reward, nexrt_state, done in mini_sample:
        #    self.trainer.train_step(state, action, reward, next_state, done)

    def train_short_memory(self, state, action, reward, next_state, done):
            self.memory.append((state, action, reward, next_state, done))


    
    def get_action(self, state):
        # random moves: tradeoff exploration / exploitation
        self.epsilon = 80 - self.n_games
        final_move = [0,0,0]
        if random.randint(0, 200) < self.epsilon:
            move = random.randint(0, 2)
            final_move[move] = 1
        else:
            state0 = torch.tensor(state, dtype=torch.float)
            prediction = self.model(state0)
            move = torch.argmax(prediction).item()
            final_move[move] = 1

        return final_move

def train():
    plot_scores = []
    plot_mean_scores = []
    total_score = 0
    record = 0
    survival_time = []
    survival_mean_time =[]
    record_t =0
    total_time =0
    agent = Agent()
    game = SnakeGameAI()
    start_time = time.time()

    while True:
        # get old state
        state_old = agent.get_state(game)

        # get move
        final_move = agent.get_action(state_old)

        # perform move and get new state
        reward, done, score = game.play_step(final_move)
        state_new = agent.get_state(game)

        # trap
        #game.get_potential_trap(game.snake[0])

        # train short memory
        agent.train_short_memory(state_old, final_move, reward, state_new, done)
        
        #agent.adjust_learning_rate(score)

        # remember
        agent.remember(state_old, final_move, reward, state_new, done)

        if done:

            end_time = time.time()
            # train long memory, plot result
            game.reset()
            agent.n_games += 1
            agent.train_long_memory()
            Etime =  end_time - start_time
            if score > record:
                record = score                                                  
                record_t = Etime
                agent.model.save()
                
            # Scores
            print('Game', agent.n_games, 'Score', score, 'Record:', record)
            
            plot_scores.append(score)
            total_score += (score)
            mean_score = total_score / agent.n_games
            plot_mean_scores.append(mean_score)

            #Time
            print(f"Time : {Etime:.2f} Record Survival Time : {record_t:.2f}")

            survival_time.append(Etime)
            total_time += (Etime)
            mean_time = total_time/agent.n_games
            survival_mean_time.append(mean_time)

            plot(plot_scores, plot_mean_scores, survival_time, survival_mean_time,agent.n_games)

            

if __name__ == '__main__':
    train()