import matplotlib.pyplot as plt
from IPython import display
import pandas as pd
import os

# Ensure the output folder exists
os.makedirs("plots", exist_ok=True)

# Initialize CSV file
csv_file = "game_data.csv"
if not os.path.isfile(csv_file):
    # Create a new DataFrame with headers
    df = pd.DataFrame(columns=['Game', 'Score', 'Mean_Score', 'Survival_Time', 'Mean_Survival_Time'])
    df.to_csv(csv_file, index=False)

# Interactive mode
plt.ion()

def plot(scores, mean_scores, survival_time, mean_time, game_number):
    display.clear_output(wait=True)
    
    # Create subplots (1 row, 2 columns)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    # Plot Scores
    ax1.plot(scores, label='Score')
    ax1.plot(mean_scores, label='Mean Score')
    ax1.set_title('Scores vs Number of Games')
    ax1.set_xlabel('Number of Games')
    ax1.set_ylabel('Score')
    ax1.set_ylim(ymin=0)
    ax1.text(len(scores)-1, scores[-1], str(scores[-1]))
    ax1.text(len(mean_scores)-1, mean_scores[-1], str(mean_scores[-1]))
    ax1.legend()

    # Plot Survival Time
    ax2.plot(survival_time, label='Survival Time')
    ax2.plot(mean_time, label='Mean Survival Time')
    ax2.set_title('Survival Time vs Number of Games')
    ax2.set_xlabel('Number of Games')
    ax2.set_ylabel('Survival Time')
    ax2.set_ylim(ymin=0)
    ax2.text(len(survival_time)-1, survival_time[-1], str(survival_time[-1]))
    ax2.text(len(mean_time)-1, mean_time[-1], str(mean_time[-1]))
    ax2.legend()

    plt.tight_layout()  # Adjust layout for better spacing
    display.display(fig)  # Display the entire figure

    # Save data to CSV after each plot
    data = {
        'Game': [game_number],
        'Score': [scores[-1]],
        'Mean_Score': [mean_scores[-1]],
        'Survival_Time': [survival_time[-1]],
        'Mean_Survival_Time': [mean_time[-1]]
    }
    df = pd.DataFrame(data)
    df.to_csv(csv_file, mode='a', header=False, index=False)

    # Save plot every 100 games
    if game_number % 100 == 0:
        fig.savefig(f"plots/plot_{game_number}.png")

    plt.pause(1)
    plt.close(fig)  # Close the figure to prevent duplication
